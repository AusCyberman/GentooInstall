maim -s -u | xclip -selection clipboard -t image/png -i
